﻿using System;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // RandomList list = new RandomList();
            // list.Add("First question");
            // list.Add("Second question");
            // list.Add("Third question");
            // list.Add("Forth question");
            // list.Add("Fifth question");
            // list.Add("Sixth question");

            // while (list.Count > 0)
            // {
            //     System.Console.WriteLine(list.GetRandomElement());
            // }
        }
    }
}