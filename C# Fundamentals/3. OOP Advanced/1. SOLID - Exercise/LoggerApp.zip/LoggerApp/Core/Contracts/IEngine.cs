namespace LoggerApp.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}