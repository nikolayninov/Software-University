namespace LoggerApp.Layouts.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}